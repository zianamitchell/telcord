# TelCord Repository

This is the TelCord forward only version 2 blueprint. 
It is a creation of ZM Global IT.
----

# About TelCord
TelCord is a automated system that sends message forwarded to my telegram bot to a specified discord channel on a specified discord server set up by the user via Integromat.  
---

# Installation

Import to Integromat (once done it should be located in your scenarios section)
----

# Customization

Once uploaded to Integromat the only modules that should need to be customized are the discord modules.

You need to either select an existing discord connection or create a new one. Do this for all discord modules. Both discord modules should be connected to the same discord channel/server.

In case the telegram module lost it's connection during the export/import process use this key: 834378953:AAFeK-mbKS3y6AkfkZuD-w0YmKlsARh56qs